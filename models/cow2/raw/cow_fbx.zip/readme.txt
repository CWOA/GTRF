﻿Cow model for games, educational, visualization and other purposes. 
Made with Maya 7, clean topology, no N-gons, mostly quads and just few triangles.
UV mapped and fully textured, unwrapping done with no overlapping. 
Maya 7 (.ma, .mb), OBJ (.obj with .mtl), 3ds Max 2009 (.max) and Autodesk FBX (.fbx) format included.
Polygons: 1026 quads/ 2038 triangles
Vertices: 1023
Edges: 2045
UVs: 1279
Textures included in textures_cow.zip file:
-1024×1024 .jpg diffuse (color) map
-1024×1024 .psd diffuse (color) map with layers

